<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>

<h1>Data Dosen</h1>

<div class="container">
    <a href="<?php echo base_url() ?>/dosen/create" class="btn btn-primary my-3">Tambah Data</a>
    <div class="col-md-8">
        <table class="table">
            <tr>
                <td>No</td>
                <td>Nama</td>
                <td>NIDN</td>
                <td>Email</td>
                <td>Aksi</td>
            </tr>
            <?php $i = 1;
            foreach ($dosen as $d) : ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><?= $d['nama_dosen']; ?></td>
                    <td><?= $d['nidn_dosen']; ?></td>
                    <td><?= $d['email_dosen']; ?></td>
                    <td>
                        <a href="<?php echo base_url() ?>/dosen/update/<?= $d['id_dosen']; ?>" class="btn btn-success">Update</a>
                        <a href="<?php echo base_url() ?>/dosen/delete/<?= $d['id_dosen']; ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

<?= $this->endSection(); ?>