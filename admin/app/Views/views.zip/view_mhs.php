<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>
<h1>Data Mahasiswa</h1>


<div class="container">
	<a href="<?php echo base_url() ?>/mahasiswa/create" class="btn btn-primary my-3">Tambah Data</a>
	<div class="col-md-8">
		<table class="table">
			<tr>
				<td>No</td>
				<td>NIM</td>
				<td>Nama</td>
				<td>Kelas</td>
				<td>Email</td>
				<td>Alamat</td>
				<td>Aksi</td>
			</tr>
			<?php $i = 1;
			foreach ($mahasiswa as $m) : ?>
				<tr>
					<td><?= $i++; ?></td>
					<td><?= $m['nim']; ?></td>
					<td><?= $m['nama']; ?></td>
					<td><?= $m['kelas']; ?></td>
					<td><?= $m['email']; ?></td>
					<td><?= $m['alamat']; ?></td>
					<td>
						<a href="<?php echo base_url() ?>/mahasiswa/update/<?= $m['id']; ?>" class="btn btn-success">Update</a>
						<a href="<?php echo base_url() ?>/mahasiswa/delete/<?= $m['id']; ?>" class="btn btn-danger">Delete</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
	</div>
</div>

<?= $this->endSection(); ?>