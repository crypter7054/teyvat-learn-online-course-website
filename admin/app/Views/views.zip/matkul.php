<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>

<h1>Data Mata Kuliah</h1>

<div class="container">
    <a href="<?php echo base_url() ?>/matkul/create" class="btn btn-primary my-3">Tambah Data</a>
    <div class="col-md-8">
        <table class="table">
            <tr>
                <td>No</td>
                <td>Mata Kuliah</td>
                <td>SKS</td>
                <td>Jadwal</td>
                <td>Ruang</td>
                <td>Aksi</td>
            </tr>
            <?php $i = 1;
            foreach ($matkul as $m) : ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><?= $m['nama_matkul']; ?></td>
                    <td><?= $m['sks']; ?></td>
                    <td><?= $m['jadwal']; ?></td>
                    <td><?= $m['ruang']; ?></td>
                    <td>
                        <a href="<?php echo base_url() ?>/matkul/update/<?= $m['id_matkul']; ?>" class="btn btn-success">Update</a>
                        <a href="<?php echo base_url() ?>/matkul/delete/<?= $m['id_matkul']; ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

<?= $this->endSection(); ?>