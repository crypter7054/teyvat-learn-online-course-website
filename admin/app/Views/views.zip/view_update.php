<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container">
	<h2>Update Data Mahasiswa</h2>
	<div class="col-md-8">
		<form action="<?php echo base_url() ?>/mahasiswa/save/<?= $mahasiswa['id']; ?>" method="post">
			<div class="form-group">
				<label>NIM</label>
				<input type="text" class="form-control" name="nim" value="<?= $mahasiswa['nim'] ?>">
			</div>
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control" name="nama" value="<?= $mahasiswa['nama'] ?>">
			</div>
			<div class="form-group">
				<label>Kelas</label>
				<input type="text" class="form-control" name="kelas" value="<?= $mahasiswa['kelas'] ?>">
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" class="form-control" name="email" value="<?= $mahasiswa['email'] ?>">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<input type="text" class="form-control" name="alamat" value="<?= $mahasiswa['alamat'] ?>">
			</div>
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
</div>

<?= $this->endSection(); ?>