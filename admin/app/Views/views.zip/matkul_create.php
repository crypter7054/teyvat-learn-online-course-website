<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container mt-5">
    <h2>Tambah Data Mata Kuliah</h2>
    <div class="col-md-6">
        <form action="<?php echo base_url() ?>/matkul/save" method="post">
            <?= csrf_field(); ?>
            <div class="form-group">
                <label>Nama Mata Kuliah</label>
                <input type="text" class="form-control" name="nama">
            </div>
            <div class="form-group">
                <label>SKS</label>
                <input type="number" class="form-control" name="sks">
            </div>
            <div class="form-group">
                <label>Jadwal</label>
                <input type="text" class="form-control" name="jadwal">
            </div>
            <div class="form-group">
                <label>Ruang</label>
                <input type="text" class="form-control" name="ruang">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Add Data</button>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>