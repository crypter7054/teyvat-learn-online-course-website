<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container">
    <h2>Update Data Mata Kuliah</h2>
    <div class="col-md-8">
        <form action="<?php echo base_url() ?>/matkul/save/<?= $matkul['id_matkul']; ?>" method="post">
            <div class="form-group">
                <label>Nama Mata Kuliah</label>
                <input type="text" class="form-control" name="nama" value="<?= $matkul['nama_matkul'] ?>">
            </div>
            <div class="form-group">
                <label>SKS</label>
                <input type="number" class="form-control" name="sks" value="<?= $matkul['sks'] ?>">
            </div>
            <div class="form-group">
                <label>Jadwal</label>
                <input type="text" class="form-control" name="jadwal" value="<?= $matkul['jadwal'] ?>">
            </div>
            <div class="form-group">
                <label>Ruang</label>
                <input type="text" class="form-control" name="ruang" value="<?= $matkul['ruang'] ?>">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>