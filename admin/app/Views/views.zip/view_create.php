<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container mt-5">
	<h2>Tambah Data Mahasiswa</h2>
	<div class="col-md-6">
		<form action="<?php echo base_url() ?>/mahasiswa/save" method="post">
			<?= csrf_field(); ?>
			<div class="form-group">
				<label>NIM</label>
				<input type="text" class="form-control" name="nim">
			</div>
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control" name="nama">
			</div>
			<div class="form-group">
				<label>Kelas</label>
				<input type="text" class="form-control" name="kelas">
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" class="form-control" name="email">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<textarea name="alamat" class="form-control" placeholder="Alamat....."></textarea>
			</div>
			<button type="submit" class="btn btn-primary mt-3">Add Data</button>
		</form>
	</div>
</div>

<?= $this->endSection(); ?>