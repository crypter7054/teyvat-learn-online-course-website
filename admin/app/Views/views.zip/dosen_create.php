<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container mt-5">
    <h2>Tambah Data Dosen</h2>
    <div class="col-md-6">
        <form action="<?php echo base_url() ?>/dosen/save" method="post">
            <?= csrf_field(); ?>
            <div class="form-group">
                <label>NIDN</label>
                <input type="text" class="form-control" name="nidn">
            </div>
            <div class="form-group">
                <label>Nama Dosen</label>
                <input type="text" class="form-control" name="nama">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Add Data</button>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>