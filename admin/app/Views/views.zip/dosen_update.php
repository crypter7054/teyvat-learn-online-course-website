<?= $this->extend('layout/navbar'); ?>

<?= $this->section('content'); ?>


<div class="container">
    <h2>Update Data Dosen</h2>
    <div class="col-md-8">
        <form action="<?php echo base_url() ?>/dosen/save/<?= $dosen['id_dosen']; ?>" method="post">
            <div class="form-group">
                <label>NIDN</label>
                <input type="text" class="form-control" name="nidn" value="<?= $dosen['nidn_dosen'] ?>">
            </div>
            <div class="form-group">
                <label>Nama Dosen</label>
                <input type="text" class="form-control" name="nama" value="<?= $dosen['nama_dosen'] ?>">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" value="<?= $dosen['email_dosen'] ?>">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>